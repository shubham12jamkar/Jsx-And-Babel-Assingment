function App() {
  return (
    <div>
      <Person
        name="Shubham"
        age={27}
        hobbies={["Playing cricket","Watching tv"]}
      />
      <Person name="Sam" age={34} hobbies={["painting", "reading"]} />
      <Person
        name="Akshay"
        age={8}
        hobbies={["skateboarding", "singing"]}
      />
      <Person
        name="Sanjay"
        age={8}
        hobbies={["reading", "eating vegetables"]}
      />
    </div>
  );
}
