/** NamedComponent: greets
 *
 * Props:
 * - name: name to introduce self with
 */

function NamedComponent({ name }) {
  return <p>My name is {name}.</p>;
}
