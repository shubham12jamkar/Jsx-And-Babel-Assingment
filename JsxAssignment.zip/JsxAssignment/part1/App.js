function App() {
  return (
    <div>
      <FirstComponent />
      <SecondComponent/>
      <NamedComponent name="Shubham" />
    </div>
  );
}
