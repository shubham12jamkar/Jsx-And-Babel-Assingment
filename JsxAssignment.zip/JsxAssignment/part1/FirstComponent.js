/** Named Component: super-basic static. */

function FirstComponent() {
  return <h1>First Component.</h1>;
}
