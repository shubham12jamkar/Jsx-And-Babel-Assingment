/** Named Component: super-basic static. */

function SecondComponent() {
    return <h1>Second Component.</h1>;
  }
  