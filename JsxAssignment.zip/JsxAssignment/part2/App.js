function App() {
  return (
    <div>
      <Tweet
        name="Shubham"
        username="shubh"
        date={new Date().toDateString()}
        message="Hi Everyone!!"
      />
      <Tweet
        name="Akshay"
        username="Akky"
        date={new Date().toDateString()}
        message="Hi Buddy!!"
      />
      <Tweet
        name="Sanjay"
        username="Sanju"
        date={new Date().toDateString()}
        message="Hi Friends!!"
      />
    </div>
  );
}
